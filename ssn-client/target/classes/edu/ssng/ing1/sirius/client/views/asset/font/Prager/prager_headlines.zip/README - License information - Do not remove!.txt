EN > You�ve just downloaded the "Prager Headlines" font (2019).

"Prager Headlines" font has been created by Lukas Krakora and is free for non-commercial use only.

If you'd like to use the font commercially contact me at my email krraaa@yahoo.com to get the information about pricing. Please type "Prager Headlines" in subject of your message.

I can add any extra characters or customize the font for purchasers of the commercial license.

Any donations from non-commercial users to my Paypal krraaa@yahoo.com are welcome. 

You can find my other fonts on www.typewriterfonts.net or www.dafont.com/lukas-krakora.d1281

And my FB page is: facebook.com/typewriterfonts

Thank you.

LK



CZ > Prave jste si stahli font "Prager Headlines" (2019).

Font "Prager Headlines" byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely.

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu krraaa@yahoo.com a dozvite se cenu.

Pokud mi budete psat, prosim napiste do predmetu zpravy "Prager Headlines".

V pripade potreby mohu zajemcum o komercni licenci pridat k fontu dalsi znaky, ci jakkoli upravit existujici.

Jakekoliv financni prispevky od nekomercnich uzivatelu na muj Paypal krraaa@yahoo.com jsou vitany.

M� dal�� fonty naleznete na www.typewriterfonts.net a na www.dafont.com/lukas-krakora.d1281

Tak� m��ete nav�t�vit m� FB str�nky facebook.com/typewriterfonts

Diky.

LK

